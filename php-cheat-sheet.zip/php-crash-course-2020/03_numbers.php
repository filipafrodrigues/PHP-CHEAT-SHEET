<?php

// Declaring numbers

$a = 5;
$b = 4;
$c = 1.2;


// Arithmetic operations

echo ($a + $b) * $c . '<br>'; // 10.8
echo $a - $b . '<br>'; //substraction = 1
echo $a * $b . '<br>'; //multiplication = 20 
echo $a / $b . '<br>'; //diviser = 1.25
echo $a % $b . '<br>'; //reminder = 1

// Assignment with math operators

//$a += $b; echo $a. '<br>'; // $a = 9
//$a -= $b; echo $a. '<br>'; // $a = 1
//$a *= $b; echo $a. '<br>'; // $a = 20
//$a /= $b; echo $a. '<br>'; // $a = 1.2
//$a %= $b; echo $a. '<br>'; // $a = 1

// Increment operator

echo $a++. '<br>'; // 5 is printed  but the value will increase by 1 and will become 6
echo ++$a. '<br>'; // the value is increased and will become 7 and then is printed out

// Decrement operator

// Number checking functions

// Conversion

// Number functions

// Formatting numbers

// https://www.php.net/manual/en/ref.math.php
