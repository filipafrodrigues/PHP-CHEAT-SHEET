<?php

$url = 'https://jsonplaceholder.typicode.com/users';
// Sample example to get data.

// Get response status code

// set_opt_array

// Post request