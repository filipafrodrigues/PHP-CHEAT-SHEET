<?php

// Print current date

// Print yesterday

// Different format: https://www.php.net/manual/en/function.date.php

// Print current timestamp

// Parse date: https://www.php.net/manual/en/function.date-parse.php

// Parse date from format: https://www.php.net/manual/en/function.date-parse-from-format.php
