<?php

// What is a variable

// Variable types

/*String
Integer
Float/Double
Boolean
Null
Array
Object
Resource*/


// Declare variables

$name = 'Filipa'; //String
$age = '22'; //Integer
$isFemale = true; //Boolean 
$height = 1.56; //Float/Double
$salary = null; //Null

// Print the variables. Explain what is concatenation

echo $name. '<br>';
echo $age. '<br>';
echo $isFemale. '<br>';
echo $height. '<br>';
echo $salary. '<br>';

// Print types of the variables

echo gettype ($name). '<br>';
echo gettype ($age). '<br>';
echo gettype ($isFemale). '<br>';
echo gettype ($height). '<br>';
echo gettype ($salary). '<br>';

// Print the whole variable
var_dump($name, $age, $isFemale, $height, $salary);

// Change the value of the variable

$name = false;

// Print type of the variable
echo gettype($name). '<br>'; 

// Variable checking functions

is_string($name); //false due to the fact we changed the variable value
is_int($age); //true
is_bool($isFemale); //true
is_double($height); //true


// Check if variable is defined

isset($name); // true
isset($address); //false because is not declared

// Constants

define('PI', 3.14);
echo PI. '<br>';

// Using PHP built-in constants
echo SORT_ASC. '<br>'; //some number
echo PHP_INT_MAX. '<br>'; //maximum number the integer can print in PHP 
