<?php

// while

// Loop with $counter

// do - while

// for

// foreach

// Iterate Over associative array.